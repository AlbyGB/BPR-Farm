Heyo! Thanks for downloading the Sprout Lands UI asset pack. 
-Made by: Cup Nooble 

This asset pack is part of a series of different asset packs, 
so let me know if there's any specific sprites you'd like in future packs.
here is a link to the first pack in the Sprout Lands series : https://cupnooble.itch.io/sprout-lands-asset-pack 

License - Free Basic Pack
  - You can modify the assets.
  - You can not redistribute or resale, even if modified.
  - You can only use these assets in non-commercial projects. [ Also No NFT's pls ]
( If you want to make something commercial with these sprites contact me or buy the Premium version )

Follow Sprout Lands on Twitter for future updates :
https://twitter.com/Sprout_Lands

If you enjoy this asset pack consider leaving a rating and a comment. 
It really helps to support this project! :D
